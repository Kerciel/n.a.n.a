<?php  
ob_start(); ?>



<?= styleTitreNiveau1("partenaires", COLOR_TITRE_ASSO) ?>
<div class="row">
<div class="card col-auto mx-auto mt-2" style="width: 18rem;">
  <img src="<?= URL ?>public/sources/images/Autres/updp-logo.png" class="card-img-top p-1" alt="updp">
  <div class="card-body text-center">
    <h5 class="card-title perso_ColorRoseMenu perso_policeTitre perso_textShadow">UPDP 09</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="http://www.updp-09.fr" class="btn btn-primary">Visiter le site</a>
  </div>
</div>

<div class="card col-auto mx-auto mt-2" style="width: 18rem;">
  <img src="<?= URL ?>public/sources/images/Autres/updp-logo.png" class="card-img-top p-1" alt="updp">
  <div class="card-body text-center">
    <h5 class="card-title perso_ColorRoseMenu perso_policeTitre perso_textShadow">UPDP 09</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="http://www.updp-09.fr" class="btn btn-primary">Visiter le site</a>
  </div>
</div>

<div class="card col-auto mx-auto mt-2" style="width: 18rem;">
  <img src="<?= URL ?>public/sources/images/Autres/updp-logo.png" class="card-img-top p-1" alt="updp">
  <div class="card-body text-center">
    <h5 class="card-title perso_ColorRoseMenu perso_policeTitre perso_textShadow">UPDP 09</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="http://www.updp-09.fr" class="btn btn-primary">Visiter le site</a>
  </div>
</div>



</div>

<?php  
$content = ob_get_clean();
require_once ("views/front/commons/template.php");
 ?>