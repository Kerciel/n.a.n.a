<?php  
ob_start();

 echo styleTitreNiveau1("Association Nos Amis - Nos Animaux(N.A.N.A) Clermont(Ariège 09)",COLOR_TITRE_ASSO);
?>

<div class="row align-items-center">
    <div class="col-12 col-lg-3 text-center">
        <img class="img-fluid" src="<?= URL ?>public/sources/images/Autres/logoNANA2.jpg" alt="image logo NANA"/>
    </div>
    <div class=" col-12 col-lg-9 mt-3">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus, non? Enim dignissimos quae adipisci quam, autem laboriosam nemo perspiciatis totam saepe voluptatem odit? Fugiat molestiae deserunt recusandae officia aliquid a?</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam eligendi doloremque iusto repellat, id, repudiandae nesciunt distinctio officia amet quia deleniti iure iste eaque libero sed voluptatum ipsam sit animi!</p>
    </div>
</div>
<hr>
<?=
styleTitreNiveau2("L'Equipe",COLOR_TITRE_ASSO);
?>

<div class="row align-items-center">
    <div class="col-12 col-lg-3 text-center">
        <img class="img-fluid" style="height:200px;" src="<?= URL ?>public/sources/images/Animaux/Chats/Odin/Odin.jpg" alt="image logo NANA"/>
    </div>
    <div class=" col-12 col-lg-9 mt-3">
        <span class="badge badge-primary">Julie</span>:presidente<br/>
        <span class="badge badge-success">Karine</span>:trésorière<br/>
        <span class="badge badge-warning">Marie</span>:secrétaire<br/>
        <span class="badge badge-danger">Floriane</span>:secrétaire adjoint<br/>
    </div>
</div>
<?php  
$content = ob_get_clean();
require_once("views/front/commons/template.php");
?>