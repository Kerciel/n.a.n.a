<?php  
ob_start();
?>
<?= 
styleTitreNiveau1('Mentions Légal', COLOR_TITRE_CONTACT);
?>
<div class="pl-2 no-gutters" >
   <h2>A propos</h2>
   <p class="pl-2">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsam iure asperiores quae, sequi molestias mollitia nesciunt sint, ipsa aperiam porro rerum nulla vero saepe quibusdam voluptates deserunt vel excepturi nisi.</p>
   <h2>Mentions légal</h2>
   <p class="pl-2">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Hic possimus fugiat dolorum quia tempora eligendi, deleniti sit minima suscipit! Ratione!</p>
   <p class="pl-2">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Similique, assumenda.</p>
</div>

<?php  
$content = ob_get_clean();
require_once "views/front/commons/template.php";
 ?>