<?php  
ob_start();
?>
<?= 
styleTitreNiveau1('Donnations', COLOR_TITRE_CONTACT);
?>
<div class="no-gutters" style="padding-left:20px;">
  <?= 
    styleTitreNiveau2('Pourquoi faire un don?', COLOR_TITRE_CONTACT);
  ?>

  <div class= "d-flex flex-column" style="padding-left: 50px;">
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque, adipisci iste praesentium necessitatibus dolor ratione atque deserunt saepe, quod, rem debitis animi alias vero inventore ipsam. Omnis provident quisquam officia tenetur animi soluta odit at beatae, distinctio corrupti expedita quia!</p>
    <P>Lorem ipsum dolor sit amet consectetur adipisicing elit. In provident impedit atque quod ipsum suscipit. Nesciunt minima optio, suscipit dolores provident voluptatibus cum consectetur porro, qui neque eius similique molestias!</P>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem eveniet nisi quisquam deserunt quod ex suscipit repellendus molestias nam consectetur doloremque, adipisci minus harum obcaecati repudiandae nulla impedit dolorum vitae.</p>  
  </div>
</div>

<?php  
$content = ob_get_clean();
require_once "views/front/commons/template.php";?>